#Révision sur l’apurement

#Exercice 1
#1. Importer la base “céréales”
path="G:/Cours R 2023"
library(haven)
cereal=read_dta(file=paste0(path,"/cereales.dta"))
#2. Renommer l’ensemble des variables suivant le dictionnaire des variables, en des noms plus parlant et
#maximum 10 charactères
oldnames=colnames(cereal)
length(oldnames)
newnames=c("Key","id","Cereal_id","Other","quantity","Units","Size","provenance","Other_prov","frequency","Achatqty","Achatunit","Achatsize","Lastachatval")
colnames(cereal)=newnames
View(cereal)
#3. Décrire les variables d’intérêt
interest=c(5,6,7,10,11,12,13,14)
for (i in interest){
  var_numeric=unlist(cereal[,i])
  print(summary(cereal[,i]))
  print(quantile(cereal[,i],na.rm=TRUE))
  hist(var_numeric)
}
#4. identifier les valeurs manquantes et les imputer
na=is.na(cereal)
colSums(na)
#Imputation par remplacement par la moyenne
for (i in 5:14){
  var_numeric=unlist(cereal[,i])
  mean_var=mean(var_numeric,na.rm = TRUE)
  var_numeric[is.na(var_numeric)]=mean_var
  cereal[,i]=list(var_numeric)
}
View(cereal)
#5. Importer la base table de conversion
path="G:/Cours R 2023"
Convert_tab=read.csv2(file=paste0(path,"/Table de conversion phase 2.csv"))
View(Convert_tab)
#6. Décrire la variable poids
numerik=as.numeric(Convert_tab$poids)
print(summary(numerik))
print(quantile(numerik,na.rm = TRUE))
weight_num=unlist(numerik)
hist(weight_num)
#7. Créer une clé d’identification dans les deux bases : une concaténation des variables produitID-UniteID-TailleID.
m=length(Convert_tab$produitID)
print(m)
identification=list()
for (i in 1:(m)){
  identification=append(identification,paste(Convert_tab[i,1],Convert_tab[i,3],Convert_tab[i,5], sep = "-"))
}
identification=as.matrix(identification)
identification=unlist(identification)
Convert_tab=cbind(Convert_tab,identification)
View(Convert_tab)

n=length(cereal$Cereal_id)
identification = list()
for (i in 1:(n)){
  identification=append(identification,paste(cereal$Cereal_id[i],cereal$Units[i],cereal$Size[i], sep = "-"))
}
identification = as.matrix(identification)
identification=unlist(identification)
cereal=cbind(cereal,identification)
View(cereal)
#8. Fusionner les deux bases
merging=merge(cereal,Convert_tab,by="identification",all=TRUE)
View(merging)
#9. Convertir les quantités consommées en unités standards. Ind: Creer une nouvelle variable qui calcule
#le poids consommé durant les 7 derniers jours ensuite la raméné en année.
quantity=as.numeric(merging$quantity)
poids=as.numeric(merging$poids)
merging$poids_consomme <- quantity * poids / 1000 * 7
merging$poids_annuel <- merging$poids_consomme * 52
#10. Générer une variable “taille_men” comprise entre 1 et 30. La moyenne nationale est de 9. La taille est
#un entier. Cette variable sera unique pour chaque ménage qui est identifié par interview_key. Chaque
#interview_key est un ménage et donc chaque interview_key devra avoir une valeur unique.
Key <- unique(cereal$Key)
n=length(Key)
print(n)
taille_men=rnorm(n,mean=9)
taille_men=pmax(1,pmin(30, round(taille_men)))
View(taille_men)
taille_men_df <- data.frame(Key = unique(cereal$Key), taille_men = taille_men)
merged_data <- merge(cereal, taille_men_df, by = "Key")
View(merged_data)
#11. Importer la base calories et fusionner celle avec la base. Cacluer la consommation calorie par tête.
#Nettoyer d’abord les valeurs manquantes et les valeurs aberrantes.

#Exercice 2 :
#1. Fonction d’importation dont l’argument sera le chemin et nom du fichier

import=function(path,file){
  data=read.csv2(file = paste0(path,file))
  return(data)
}
#2. Fonction qui renomme les variables
renaming=function(data){
  newnames=c("Key","id","product_id","Other","quantity","Units","Size","provenance","Other_prov","frequency","Achatqty","Achatunit","Achatsize","Lastachatval")
  colnames(data)=newnames
  return(data)
}
#3. Fonction qui fusionne deux bases
fusion=function(data1,data2){
  data=merge(data1,data2,by=intersect(data1,data2))
  return(data)
}
#4. Fonction qui détecte les valeurs manquantes
detect_na=function(data){
  na=is.na(data)
  colSums(na)
}
#5. Fonction qui impute les valeurs manquantes
impute_na=function(data){
  for (i in 5:14){
    var_numeric=unlist(data[,i])
    mean_var=mean(var_numeric,na.rm = TRUE)
    var_numeric[is.na(var_numeric)]=mean_var
    data[,i]=list(var_numeric)
  }
  return(data)
}
#6. Fonction qui détecte les valeurs aberrantes
detect_aberrant=function(data){
  outliers=list()
  for (i in 1:14){
    var=data[,i]
    median_var <- median(var, na.rm = TRUE)
    iqr_var <- IQR(var, na.rm = TRUE)
    lower_limit <- median_var - 1.5 * iqr_var
    upper_limit <- median_var + 1.5 * iqr_var
    outliers_var <- which(var < lower_limit | var > upper_limit)
    outliers=append(outliers,outliers_var)
  }
  return(outliers)
}
#7. Fonction qui les corrige
replace_outliers_with_mean <- function(data) {
  for (i in 1:14){
  mean_col <- mean(data[,i], na.rm = TRUE)
  data[,i][abs(data[,i] - mean_col) > 1.5] <- mean_col
  }
  return(data)
}