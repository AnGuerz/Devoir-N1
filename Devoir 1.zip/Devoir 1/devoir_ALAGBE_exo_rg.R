####Devoir N 1:R les bases

###Révision générale

##Exercice 1

#1. Créer un script R nommé devoir_nom_exo_rg

#2. créer un data frame qui contient n lignes et m colonnes (n>100, m>10)
#• 5 varibales quantitatives ;
#• 5 variables qualitatives de type factor avec une variable binaire. > Indication : vous pouvez
#utiliser les focntions “rep”, “seq”, “rnorm”, dnorm, etc. . .

#Définir le nombre de lignes et de colonnes
n=200
m=15

#Variables quantitatives et qualitatives
datafrost=data.frame(matrix(NA,nrow=n, ncol=m))
region=c("Dakar", "Diourbel", "Fatick", "Kaolack", "Kolda", 
         "Louga", "Matam", "St Louis", "Tambacounda", "Thiès")
for (i in 1:(m)){

  if (i<=5){
    datafrost[,i]=rnorm(n, mean=5*i, sd=2*i)
  }else if (i>=6 & i<=10){
    if (i==6){
      datafrost[,i]=factor(rep(region, each=n/length(region)))
    }else if (i==7){
      datafrost[,i]=factor(sample(c("Yes","No"),n, replace=TRUE))
    }else{
      datafrost[,i]=factor(sample(c("A","B","C","D","E"),n, replace=TRUE))
    }
  }else{
    datafrost[,i]=factor(sample(rnorm(n),n, replace=TRUE))
  }
}
View(datafrost)

#3. Enregistrer le dataframe dans un objet nommé df.votreNom

df.alagbe=datafrost
View(df.alagbe)
#4. Exporter au format “csv” dont sep=“;”
write.csv2(df.alagbe,"G:/Cours R 2023/Devoir 1/base.csv")

#5. générer un rapport au format “html”

